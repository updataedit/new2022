# ChatGPT 浏览器侧边栏扩展

## 项目简介

这是一个为 Chrome 浏览器开发的 ChatGPT 侧边栏扩展，旨在提供一种快速、便捷的方式在浏览网页时访问 ChatGPT。

## 技术实现方案

### 1. 架构设计

本扩展基于 Chrome Extension Manifest V3 架构，主要由以下关键组件构成：

- **后台服务脚本 (`background.js`)**: 处理扩展的核心网络请求逻辑
- **弹出面板脚本 (`popup.js`)**: 控制用户交互界面
- **样式文件 (`panel.css`)**: 定义扩展的视觉样式

### 2. CSP 绕过技术细节

#### 2.1 动态网络请求规则

核心实现代码：

```javascript
chrome.declarativeNetRequest.updateDynamicRules({
  addRules: [
    {
      "action": {
        "type": "modifyHeaders",
        "responseHeaders": [
          { "header": "content-security-policy", "operation": "remove" },
          { "header": "x-frame-options", "operation": "remove" }
        ]
      },
      "condition": {
        "urlFilter": "https://chatgpt.com/*"
      }
    }
  ]
});
```

#### 2.2 关键技术点

- 使用 `declarativeNetRequest` 动态修改网络请求头
- 移除 CSP 和 X-Frame-Options 限制
- 针对性地仅作用于 ChatGPT 域名

### 3. 权限申请

在 `manifest.json` 中申请了以下关键权限：

```json
{
  "permissions": [
    "sidePanel",
    "declarativeNetRequest",
    "declarativeNetRequestWithHostAccess"
  ],
  "host_permissions": ["https://chatgpt.com/"]
}
```

### 4. 侧边栏实现

通过 Chrome 的 `side_panel` API 实现侧边栏功能：

```javascript
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));
```

### 5. 安全性与局限性

⚠️ 注意事项：
- 绕过 CSP 可能存在安全风险
- 依赖 ChatGPT 网站的具体实现
- 可能需要频繁更新以适应网站变化

### 6. 技术栈

- Chrome Extension Manifest V3
- JavaScript
- HTML5
- CSS3

## 安装方法

1. 克隆项目仓库
2. 在 Chrome 浏览器中启用"开发者模式"
3. 加载未打包的扩展程序
4. 选择项目根目录

## 开发与贡献

欢迎提交 Issue 和 Pull Request！

## 许可证

查看 `LICENSE` 文件了解详细信息。

## 免责声明

本扩展仅用于学习和研究目的，不对使用过程中可能产生的任何问题负责。 