document.addEventListener('DOMContentLoaded', () => {
  const iframeContainer = document.getElementById('iframe');
  
  // 创建 iframe
  const iframe = document.createElement('iframe');
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  iframe.style.border = 'none';
  
  // 默认加载 URL
  let currentUrl = 'https://chatgpt.com/';

  // 标记侧边栏是否准备就绪
  let isReady = false;

  // 安全地更新 iframe 的函数
  function safelyUpdateIframeSrc(url) {
    try {
      console.log('尝试加载URL:', url);
      
      // 验证 URL 是否合法
      new URL(url);
      
      // 更新 iframe 的 src
      iframe.src = url;
    } catch (error) {
      console.error('URL 不合法或加载失败:', error);
      
      // 回退到默认 URL
      iframe.src = 'https://chatgpt.com/';
    }
  }

  // 初始化函数
  function initialize() {
    // 将 iframe 添加到容器
    iframeContainer.appendChild(iframe);
    
    // 初始化时加载默认 URL
    safelyUpdateIframeSrc(currentUrl);

    // 标记为就绪
    isReady = true;
    console.log('侧边栏初始化完成');

    // 处理可能在初始化前积压的消息
    processMessageQueue();
  }

  // 消息处理队列
  const messageQueue = [];

  // 处理消息队列
  function processMessageQueue() {
    while (messageQueue.length > 0) {
      const message = messageQueue.shift();
      handleMessage(message);
    }
  }

  // 处理消息的函数
  function handleMessage(request) {
    if (request && request.action === 'openUrl') {
      // 更新当前 URL
      currentUrl = request.url || 'https://chatgpt.com/';
      
      console.log('收到打开URL消息:', currentUrl);
      
      // 安全地更新 iframe 的 src
      safelyUpdateIframeSrc(currentUrl);
    }
  }

  // 监听来自后台脚本的消息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('收到消息:', request);

    if (isReady) {
      // 如果已经就绪，直接处理消息
      handleMessage(request);
      sendResponse({ 
        status: 'success', 
        message: `已加载 ${currentUrl}` 
      });
    } else {
      // 如果未就绪，加入消息队列
      messageQueue.push(request);
      sendResponse({ 
        status: 'queued', 
        message: '消息已加入队列' 
      });
    }
    
    // 返回 true 以支持异步响应
    return true;
  });

  // 添加错误处理
  iframe.onerror = () => {
    console.error('iframe 加载失败:', currentUrl);
    // 如果加载失败，回退到 ChatGPT
    safelyUpdateIframeSrc('https://chatgpt.com/');
  };

  // 监听 iframe 加载完成事件
  iframe.onload = () => {
    console.log('iframe 加载完成:', currentUrl);
  };

  // 延迟初始化，确保所有事件监听器已经就绪
  setTimeout(initialize, 100);
});
