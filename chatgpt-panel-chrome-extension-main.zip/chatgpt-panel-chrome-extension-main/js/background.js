// 创建右键菜单
chrome.runtime.onInstalled.addListener(() => {
  // 创建右键菜单项：在侧边栏中打开当前页面
  chrome.contextMenus.create({
    id: "openInSidePanel",
    title: "在侧边栏中打开当前页面",
    contexts: ["all"]
  });

  // 为链接添加特定的右键菜单项：在侧边栏中打开链接
  chrome.contextMenus.create({
    id: "openLinkInSidePanel",
    title: "在侧边栏中打开链接",
    contexts: ["link"]
  });

  // 更新动态网络请求规则
  chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [
      {
        "id": 1,
        "priority": 1,
        "action": {
          "type": "modifyHeaders",
          "responseHeaders": [
            { "header": "content-security-policy", "operation": "remove" },
            { "header": "x-frame-options", "operation": "remove" }
          ]
        },
        "condition": {
          "urlFilter": "*://*/*", // 支持所有网站
          "resourceTypes": ["main_frame", "sub_frame"]
        }
      }
    ],
    removeRuleIds: [1]
  });
});

// 安全地发送消息的函数
function safelySendMessage(message, retryCount = 3) {
  return new Promise((resolve, reject) => {
    function attemptSend(remainingRetries) {
      try {
        // 确保有接收者
        if (!chrome.runtime.id) {
          reject(new Error('Extension context invalid'));
          return;
        }

        chrome.runtime.sendMessage(message, (response) => {
          // 检查是否有错误
          if (chrome.runtime.lastError) {
            console.error('发送消息时出错:', chrome.runtime.lastError);
            
            if (remainingRetries > 0) {
              console.log(`重试发送消息，剩余重试次数: ${remainingRetries}`);
              setTimeout(() => attemptSend(remainingRetries - 1), 1000);
            } else {
              reject(chrome.runtime.lastError);
            }
          } else {
            resolve(response);
          }
        });
      } catch (error) {
        console.error('消息发送异常:', error);
        
        if (remainingRetries > 0) {
          console.log(`重试发送消息，剩余重试次数: ${remainingRetries}`);
          setTimeout(() => attemptSend(remainingRetries - 1), 1000);
        } else {
          reject(error);
        }
      }
    }
    
    // 开始第一次尝试
    attemptSend(retryCount);
  });
}

// 获取当前活动标签页的 URL
function getCurrentTabUrl() {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs.length > 0) {
          resolve(tabs[0].url || 'https://chatgpt.com/');
        } else {
          console.warn('未找到活动标签页');
          resolve('https://chatgpt.com/');
        }
      });
    } catch (error) {
      console.error('获取当前标签页URL失败:', error);
      resolve('https://chatgpt.com/');
    }
  });
}

// 延迟函数
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 监听右键菜单点击事件
chrome.contextMenus.onClicked.addListener((info, tab) => {
  // 处理当前页面打开
  if (info.menuItemId === "openInSidePanel") {
    // 尝试获取 URL 的多种方式
    const currentUrl = 
      info.pageUrl || 
      info.linkUrl || 
      (tab && tab.url);
    
    console.log('尝试打开页面URL:', {
      linkUrl: info.linkUrl,
      pageUrl: info.pageUrl,
      tabUrl: tab && tab.url
    });
    
    // 打开侧边栏
    chrome.sidePanel.open({ windowId: tab.windowId });
    
    // 如果 URL 不存在，获取当前活动标签页的 URL
    const urlPromise = currentUrl 
      ? Promise.resolve(currentUrl) 
      : getCurrentTabUrl();
    
    // 发送消息到侧边栏，让其加载指定 URL
    urlPromise.then(async (url) => {
      console.log('最终确定的 URL:', url);
      
      try {
        // 增加延迟，确保侧边栏已经准备好
        await delay(500);
        
        // 尝试发送消息
        await safelySendMessage({
          action: 'openUrl',
          url: url
        });
      } catch (error) {
        console.error('发送页面URL消息失败:', error);
        
        try {
          // 兜底方案：打开 ChatGPT
          await safelySendMessage({
            action: 'openUrl',
            url: 'https://chatgpt.com/'
          });
        } catch (fallbackError) {
          console.error('兜底方案失败:', fallbackError);
        }
      }
    }).catch(error => {
      console.error('获取 URL 失败:', error);
    });
  }
  
  // 处理链接打开
  if (info.menuItemId === "openLinkInSidePanel") {
    const linkUrl = info.linkUrl;
    
    console.log('尝试打开链接URL:', linkUrl);
    
    if (linkUrl) {
      // 打开侧边栏
      chrome.sidePanel.open({ windowId: tab.windowId });
      
      // 发送消息到侧边栏，让其加载链接
      safelySendMessage({
        action: 'openUrl',
        url: linkUrl
      }).catch(error => {
        console.error('发送链接URL消息失败:', error);
        
        // 兜底方案：打开 ChatGPT
        safelySendMessage({
          action: 'openUrl',
          url: 'https://chatgpt.com/'
        });
      });
    }
  }
});

// 设置侧边栏行为：点击扩展图标时打开面板
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));

 